#ifndef FUNCIONES_GRUPO_H_INCLUDED
#define FUNCIONES_GRUPO_H_INCLUDED
/*
Aquí deben hacer los includes de sus archivos individuales, por ejemplo:
#include "funciones_rufino.h"
 */

#include <stdbool.h>
#include "funciones_massa.h"
#include "funciones_resano.h"
#include "funciones_tomadin.h"

int solucion(int argc, char* argv[]);

#endif // FUNCIONES_GRUPO_H_INCLUDED
