#ifndef funciones_resano_H_INCLUDED
#define funciones_resano_H_INCLUDED
#include "stdbool.h"
#include "funciones_grupo.h"

#define BLUE 0
#define GREEN 1
#define RED 2


bool imagenTransformada(VecEffectList *, TDAVectList*, Pixeles ** , AdicDataBmp *,
        HeaderBmp *, FILE*);


#endif // funciones_resano_H_INCLUDED
